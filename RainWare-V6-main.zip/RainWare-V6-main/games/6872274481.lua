loadstring(game:HttpGet("https://api.jnkie.com/api/v1/luascripts/public/d5a3891b2df3487333ed37dd8f1cb660c74c2f9f0d125bcdd9c61cfcf88e2fc2/download"))()
